/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Calculadora;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface Calculadora extends Remote {
    double operacion(double numero1, double numero2, String operador) throws RemoteException;
}



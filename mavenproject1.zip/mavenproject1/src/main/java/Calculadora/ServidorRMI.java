/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Calculadora;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.server.UnicastRemoteObject;

public class ServidorRMI {
    public static void main(String[] args) {
        try {
            // Crear e iniciar el registro RMI
            LocateRegistry.createRegistry(1099);

            // Crear la instancia de la implementación de la calculadora
            CalculadoraImpl calculadora = new CalculadoraImpl();

            // Exportar la instancia de la calculadora como objeto remoto
            Calculadora stub = (Calculadora) UnicastRemoteObject.exportObject(calculadora, 0);

            // Registrar el objeto remoto en el registro RMI
            Naming.rebind("rmi://localhost/Calculadora", stub);

            System.out.println("Servidor RMI listo");
        } catch (Exception e) {
            System.err.println("Error en el servidor: " + e.toString());
            e.printStackTrace();
        }
    }
}

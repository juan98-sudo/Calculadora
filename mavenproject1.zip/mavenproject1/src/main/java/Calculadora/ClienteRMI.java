    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Calculadora;

/**
 *
 * @author juanp
 */
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class ClienteRMI {
    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            Calculadora calculadora = (Calculadora) registry.lookup("Calculadora");

            double resultado = calculadora.sumar(5, 3);
            System.out.println("5 + 3 = " + resultado);

            resultado = calculadora.multiplicar(4, 2);
            System.out.println("4 * 2 = " + resultado);

            resultado = calculadora.dividir(10, 2);
            System.out.println("10 / 2 = " + resultado);

            resultado = calculadora.calcularPorcentaje(200, 20);
            System.out.println("20% de 200 = " + resultado);

            resultado = calculadora.calcularRaizCuadrada(25);
            System.out.println("Raíz cuadrada de 25 = " + resultado);
        } catch (Exception e) {
            System.err.println("Error en el cliente: " + e.toString());
            e.printStackTrace();
        }
    }
}

    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Calculadora;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.Scanner;

public class ClienteRMI {
    public static void main(String[] args) {
        try {
            Calculadora calculadora = (Calculadora) Naming.lookup("rmi://localhost/Calculadora");

            Scanner scanner = new Scanner(System.in);

            System.out.print("Ingrese la expresión matemática (ejemplo: 5+6): ");
            String expresion = scanner.nextLine();

            // Separar la expresión en número y operador
            String[] partes = expresion.split("[+\\-*/%]");

            if (partes.length != 2) {
                System.err.println("Expresión inválida. Debe tener el formato: número operador número");
                return;
            }

            double numero1 = Double.parseDouble(partes[0]);
            double numero2 = Double.parseDouble(partes[1]);

            String operador = expresion.replaceAll("[^+\\-*/%]", "");

            double resultado = calculadora.operacion(numero1, numero2, operador);
            System.out.println("Resultado: " + resultado);

            scanner.close();
        } catch (Exception e) {
            System.err.println("Error en el cliente: " + e.toString());
            e.printStackTrace();
        }
    }
}


